using UnityEngine;

public class MetodsPractice : MonoBehaviour
{
    [SerializeField] int multiplicationBase;

    void Start()
    {
        Debug.Log("Hello");
        Debug.Log("Hello2");
        Debug.Log("Hello3");

        int min = Mathf.Min(1, 4, 5, 6);
        int max = Mathf.Max(1, 4, 5, 6);

        int min2 = Minimum(45, 67);

        WriteMultiplicationTable(multiplicationBase);

    }

    int Minimum(int a, int b)
    {
        int min = a < b ? a : b;
        return min;
    }
    void WriteMultiplicationTable(int baseNumber)
    {
        for (int i = 1; i <= baseNumber; i++)
        {
            for (int j = 0; j <= baseNumber; j++)
            {
                Debug.Log($"{i} * {j} = {i * j}");
            }
        }
    }
}
